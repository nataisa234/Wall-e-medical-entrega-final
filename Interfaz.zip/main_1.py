import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication
from PyQt5.uic import loadUi

import pyqtgraph as pg

class Usuario:
    def __init__(self, nombre, contrasena):
        self.nombre = nombre
        self.contrasena = contrasena

# Crear un objeto de tipo Usuario
usuario1 = Usuario("Nicolas Ramirez", "1234")
usuario2 = Usuario("Valeria Viecco", "1234")
usuario3 = Usuario("Luis Diaz", "1234")



class Login(QDialog):
    def __init__(self):
        super(Login,self).__init__()
        loadUi("login.ui",self)
        self.btnLogin.clicked.connect(self.loginfunction)
        self.inPassword.setEchoMode(QtWidgets.QLineEdit.Password)
        

    def loginfunction(self):
        user = self.inUser.text()
        password = self.inPassword.text()
        print("Successfully logged in with email: ", user, "and password:", password)
        if ((user == usuario1.nombre and password == usuario1.contrasena) or (user == usuario2.nombre and password == usuario2.contrasena) or (user == usuario3.nombre and password == usuario3.contrasena)):
            
            starMenu = StarMenu()
            widget.addWidget(starMenu)
            widget.setCurrentIndex(widget.currentIndex()+1)
        else:
            print('usuario no valido')

    def gotocreate(self):
        starMenu = StarMenu()
        widget.addWidget(starMenu)
        widget.setCurrentIndex(widget.currentIndex()+1)

class StarMenu(QDialog):
    def __init__(self):
        super(StarMenu,self).__init__()
        loadUi("star-menu.ui",self)

        self.btnGraph.clicked.connect(self.graphFunction)
        self.btnSupport.clicked.connect(self.gotoSupport)
        self.btnInfo.clicked.connect(self.gotoInfo)
        self.btnCamera.clicked.connect(self.gotoCamera)
        

    def graphFunction(self):
        Graph = Graph1()
        widget.addWidget(Graph)
        widget.setCurrentIndex(widget.currentIndex()+1)
        print("Successfully created acc with email: " "and password: ")

    def gotoSupport(self):
        support = Support()
        widget.addWidget(support)
        widget.setCurrentIndex(widget.currentIndex()+1)

    def gotoInfo(self):
        info = Info()
        widget.addWidget(info)
        widget.setCurrentIndex(widget.currentIndex()+1)

    def gotoCamera(self):
        camara = Camera()
        widget.addWidget(camara)
        widget.setCurrentIndex(widget.currentIndex()+1)
            
class Graph1(QDialog):
    def __init__(self):
        super(Graph1,self).__init__()
        loadUi("graph.ui",self)

        self.plot([1,2,3,4,5,6], [30, 32, 34, 32,33, 31])

        self.btnHome.clicked.connect(self.gotoHome)

    def plot(self, hour, temperature):
        self.graph1.plot(hour, temperature)
        self.graph2.plot(hour, temperature)
        print("Estoy graficando ")

    def gotoHome(self):
        starMenu = StarMenu()
        widget.addWidget(starMenu)
        widget.setCurrentIndex(widget.currentIndex()+1)

class Support(QDialog):
    def __init__(self):
        super(Support,self).__init__()
        loadUi("support.ui",self)

        self.btnHome.clicked.connect(self.gotoHome)

    def gotoHome(self):
        starMenu = StarMenu()
        widget.addWidget(starMenu)
        widget.setCurrentIndex(widget.currentIndex()+1)
        
class Info(QDialog):
    def __init__(self):
        super(Info,self).__init__()
        loadUi("info.ui",self)

        self.btnHome.clicked.connect(self.gotoHome)
        
    def gotoHome(self):
        starMenu = StarMenu()
        widget.addWidget(starMenu)
        widget.setCurrentIndex(widget.currentIndex()+1)

class Camera(QDialog):
    def __init__(self):
        super(Camera,self).__init__()
        loadUi("camera.ui",self)

        self.btnHome.clicked.connect(self.gotoHome)
        
    def gotoHome(self):
        starMenu = StarMenu()
        widget.addWidget(starMenu)
        widget.setCurrentIndex(widget.currentIndex()+1)


app=QApplication(sys.argv)
mainwindow=Login()
widget=QtWidgets.QStackedWidget()
widget.addWidget(mainwindow)
widget.setFixedWidth(480)
widget.setFixedHeight(620)
widget.show()
app.exec_()