# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Fri Apr 21 12:08:32 2023)---
runfile('C:/Users/USUARIO/Documents/python-projects/pag1.py', wdir='C:/Users/USUARIO/Documents/python-projects')

## ---(Thu May  4 15:36:09 2023)---
runfile('C:/Users/USUARIO/Documents/python-projects/UI/main.py', wdir='C:/Users/USUARIO/Documents/python-projects/UI')

## ---(Tue May 16 20:19:57 2023)---
runfile('C:/Users/USUARIO/Documents/python-projects/UI/main.py', wdir='C:/Users/USUARIO/Documents/python-projects/UI')